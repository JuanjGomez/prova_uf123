<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Funciones de Usuario</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: space-around;
        }
        .column {
            width: 30%;
            padding: 10px;
        }
        .column h2 {
            text-align: center;
        }
        .column input, .column button, .column ul {
            width: 100%;
            margin: 5px 0;
        }
        .column ul {
            list-style-type: none;
            padding: 0;
        }
        .column ul li {
            padding: 8px;
            background-color: #f2f2f2;
            margin-bottom: 5px;
            border-radius: 5px;
        }
        .column ul li button {
            margin-left: 10px;
        }
    </style>
</head>
<body>

    <!-- Columna 1: Formulario de búsqueda -->
    <div class="column">
        <h2>Buscar Usuarios</h2>
        <form id="searchForm">
            <input type="text" id="searchInput" placeholder="Buscar por username o nombre real">
            <button type="submit">Buscar</button>
        </form>
        <ul id="searchResults">
            <!-- Aquí se mostrarán los resultados de la búsqueda -->
        </ul>
    </div>

    <!-- Columna 2: Solicitudes de Amistad -->
    <div class="column">
        <h2>Solicitudes de Amistad</h2>
        <ul id="friendRequests">
            <li>Usuario 1 <button>Aceptar</button> <button>Rechazar</button></li>
            <li>Usuario 2 <button>Aceptar</button> <button>Rechazar</button></li>
            <!-- Más solicitudes -->
        </ul>
    </div>

    <!-- Columna 3: Amigos -->
    <div class="column">
        <h2>Amigos</h2>
        <ul id="friendsList">
            <li>Amigo 1</li>
            <li>Amigo 2</li>
            <li>Amigo 3</li>
            <!-- Más amigos -->
        </ul>
    </div>

</body>
</html>
