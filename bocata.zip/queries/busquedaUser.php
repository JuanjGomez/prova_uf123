<?php
    session_start();
    if(!isset($_SESSION['id'])){
        header('Location:../index.php');
        exit();
    } else {
        if($_SERVER['REQUEST_METHOD'] !== 'POST'){
            header('Location:../actions/principal.php');
            exit();
        } else {
            require_once '../database/conexion.php';
            try{
            $busqueda = mysqli_real_escape_string($conector, trim($_POST['busqueda']));
            $sqlBuscar = "SELECT u_username FROM tbl_usuarios WHERE u_username LIKE %?% OR u_name_real LIKE %?%";
            $stmt = mysqli_stmt_init($conector);
            mysqli_stmt_prepare($stmt, $sqlBuscar);
            mysqli_stmt_bind_param($stmt, "ss", $busqueda, $busqueda);
            mysqli_stmt_execute($stmt);
            $resultBuscar = mysqli_stmt_get_result($stmt);
            if(mysqli_num_rows($resultBuscar) > 0){
                $datos = mysqli_fetch_all($resultBuscar);
                foreach($datos as $fila){
                    echo "<div class='card text-center'>";
                    echo "<h4 class='card-header'>".$fila."</h4>";
                    echo "<form></form>";
                    echo "</div>";                }
            }
            } catch(Exception $e){
                echo "Error: ". $e->getMessage();
                die();
            }
        }
    }